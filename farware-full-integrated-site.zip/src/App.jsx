
import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import './i18n';  // ربط الترجمة
import { useTranslation } from 'react-i18next';

function DummyPage({ name }) {
  return <div className="text-center text-xl py-10">{name} Page</div>;
}

export default function App() {
  const [loading, setLoading] = useState(true);
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem("theme") === "dark");
  const [lang, setLang] = useState(() => localStorage.getItem("lang") || "en");
  const { t } = useTranslation();

  useEffect(() => {
    setTimeout(() => setLoading(false), 800);
  }, []);

  useEffect(() => {
    document.body.className = darkMode ? "dark" : "light";
    localStorage.setItem("theme", darkMode ? "dark" : "light");
  }, [darkMode]);

  useEffect(() => {
    localStorage.setItem("lang", lang);
  }, [lang]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-black text-white text-xl">
        Loading...
      </div>
    );
  }

  return (
    <Router>
      <div className={darkMode ? 'bg-black text-white min-h-screen' : 'bg-white text-black min-h-screen'}>
        <header className="fixed top-0 left-0 right-0 px-6 py-4 flex justify-between items-center shadow bg-opacity-80 z-50"
                style={{ background: darkMode ? '#111' : '#f2f2f2' }}>
          <Link to="/" className="font-bold">FarWare</Link>
          <nav className="space-x-4 text-sm">
            <Link to="/features">{t('features')}</Link>
            <Link to="/pricing">{t('pricing')}</Link>
            <Link to="/contact">{t('contact')}</Link>
            <Link to="/ip-protection">{t('ip_protection')}</Link>
          </nav>
          <div className="flex gap-2 items-center">
            <button onClick={() => setDarkMode(!darkMode)}>{darkMode ? '☀️' : '🌙'}</button>
            <select value={lang} onChange={e => setLang(e.target.value)} className="bg-transparent border px-1">
              <option value="en">EN</option>
              <option value="ar">AR</option>
              <option value="de">DE</option>
            </select>
          </div>
        </header>

        <main className="pt-24 px-6">
          <Routes>
            <Route path="/" element={<DummyPage name={t('home')} />} />
            <Route path="/features" element={<DummyPage name={t('features')} />} />
            <Route path="/pricing" element={<DummyPage name={t('pricing')} />} />
            <Route path="/contact" element={<DummyPage name={t('contact')} />} />
            <Route path="/ip-protection" element={<DummyPage name={t('ip_protection')} />} />
          </Routes>
        </main>

        <footer className="text-center py-6 text-sm opacity-70">
          © {new Date().getFullYear()} FarWare Smart
        </footer>
      </div>
    </Router>
  );
}
