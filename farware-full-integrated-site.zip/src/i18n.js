
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import translationEN from './locales/en.json';
import translationAR from './locales/ar.json';
import translationDE from './locales/de.json';

const resources = {
  en: { translation: translationEN },
  ar: { translation: translationAR },
  de: { translation: translationDE }
};

i18n
  .use(LanguageDetector)  // للكشف عن لغة المتصفح
  .use(initReactI18next)  // ربط i18next مع React
  .init({
    resources,
    fallbackLng: 'en',  // اللغة الافتراضية
    interpolation: {
      escapeValue: false,  // منع التهرب من النصوص
    },
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage'],  // تخزين اللغة في localStorage
    },
  });

export default i18n;
